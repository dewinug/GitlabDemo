from django.core.exceptions import ValidationError
from django.test import TestCase
from django.test import Client
from tutorial_2.views import index
from tutorial_2.models import TodoList
from django.http import HttpRequest
from django.utils import timezone

DUMMY_TODO_ITEM = "Dummy todo item"


def get_from_django_http(method):
    request = HttpRequest()
    response = method(request)
    return response


class TodoTableModelsTest(TestCase):

    def test_page_rendered_successfully(self):
        response = Client().get('/tutorial-2/')
        self.assertEqual(response.status_code, 200)

    def test_name_in_page(self):
        response = get_from_django_http(index)
        html_response = response.content.decode('utf8')
        self.assertIn('Izzan Fakhril Islam', html_response)

    def test_todo_table_rendered_successfully(self):
        response = get_from_django_http(index)
        html_response = response.content.decode('utf8')
        self.assertIn('<th><h5><b>Todo</b></h5></th>', html_response)

    def test_add_todo_item_via_model(self):
        TodoList.objects.create(
            date=timezone.now(),
            todo_list=DUMMY_TODO_ITEM
        )
        todo_count = TodoList.objects.all().count()
        self.assertEqual(todo_count, 1)

    def test_POST_request_create_todo(self):
        self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-12T15:15',
                'activity': DUMMY_TODO_ITEM
            }
        )
        todo_count = TodoList.objects.all().count()
        page_response = self.client.get('/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertEqual(todo_count, 1)
        self.assertIn(DUMMY_TODO_ITEM, html_response)

    def test_POST_request_create_todo_redirects(self):
        response = self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-12T15:15',
                'activity': DUMMY_TODO_ITEM
            }
        )
        self.assertRedirects(response, '/tutorial-2/')

    def test_cannot_add_empty_todo_model(self):
        new_todo = TodoList(
            date="",
            todo_list="",
        )
        with self.assertRaises(ValidationError):
            new_todo.save()
            new_todo.full_clean()

    def test_error_create_todo_from_view(self):
        response = self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '',
                'activity': ''
            }
        )
        error_msg = "ERROR: Failed to add Todo List"

        self.assertEqual(response.status_code, 200)
        self.assertRaises(ValueError)
        self.assertContains(response, error_msg)
