from django.core.exceptions import ValidationError
from django.test import TestCase
from django.test import Client
from tutorial_2.views import index
from tutorial_2.models import TodoListCommentary
from django.http import HttpRequest
from django.utils import timezone

DUMMY_TODO_COMMENTARY_ITEM = "Dummy todo commentary item"


def get_from_django_http(method):
    request = HttpRequest()
    response = method(request)
    return response


class TodoCommentaryTableModelsTest(TestCase):

    def test_page_rendered_successfully(self):
        response = Client().get('/tutorial-2/')
        self.assertEqual(response.status_code, 200)

    def test_name_in_page(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('Izzan Fakhril Islam', html_response)

    def test_todo_commentary_table_rendered_successfully(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('<th><h5><b>Comment</b></h5></th>', html_response)

    def test_add_todo_commentary_item_via_model(self):
        TodoListCommentary.objects.create(
            date=timezone.now(),
            comment=DUMMY_TODO_COMMENTARY_ITEM
        )
        todo_commentary_count = TodoListCommentary.objects.all().count()
        self.assertEqual(todo_commentary_count, 1)

    def test_POST_request_create_todo_commentary(self):
        self.client.post(
            '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        todo_comment_count = TodoListCommentary.objects.all().count()
        page_response = self.client.get('/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertEqual(todo_comment_count, 1)
        self.assertIn(DUMMY_TODO_COMMENTARY_ITEM, html_response)

    def test_POST_request_create_todo_commentary_redirects(self):
        response = self.client.post(
            '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        self.assertRedirects(response, '/tutorial-2/')

    def test_cannot_add_empty_todo_commentary_model(self):
        new_todo_commentary = TodoListCommentary(
            date="",
            comment="",
        )
        with self.assertRaises(ValidationError):
            new_todo_commentary.save()
            new_todo_commentary.full_clean()

    def test_error_create_todo_commentary_from_view(self):
        response = self.client.post(
            '/tutorial-2/add_todo_commentary/',
            data={
                'date': '',
                'comment': ''
            }
        )
        error_msg = "ERROR: Failed to add Todo List Commentary"

        self.assertEqual(response.status_code, 200)
        self.assertRaises(ValueError)
        self.assertContains(response, error_msg)
