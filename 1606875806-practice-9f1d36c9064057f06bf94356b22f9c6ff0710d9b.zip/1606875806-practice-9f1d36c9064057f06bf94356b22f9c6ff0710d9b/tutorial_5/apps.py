from django.apps import AppConfig


class Tutorial5Config(AppConfig):
    name = 'tutorial_5'
