from .base import FunctionalTest


class TodoCommentaryAndItemAestheticsTest(FunctionalTest):

    def test_layout_and_styling_todo_input_textbox(self):
        selenium_host = self.get_host_from_selenium(self.host)
        selenium_host.set_window_size(1024, 768)

        todo_date = selenium_host.find_element_by_id('todo_date')
        self.assertAlmostEqual(
            todo_date.location['x'] + todo_date.size['width'] / 2,
            740,
            delta=500
        )

    def test_layout_and_styling_todo_commentary_input_textbox(self):
        selenium_host = self.get_host_from_selenium(self.host)
        selenium_host.set_window_size(1024, 768)

        todo_commentary = selenium_host.find_element_by_id('comment_date')
        self.assertAlmostEqual(
            todo_commentary.location['x'] + todo_commentary.size['width'] / 2,
            780,
            delta=500
        )
