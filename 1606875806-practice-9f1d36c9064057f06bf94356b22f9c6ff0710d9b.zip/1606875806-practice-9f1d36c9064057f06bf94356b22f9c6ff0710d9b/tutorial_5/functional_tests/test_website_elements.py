from .base import FunctionalTest


class WebsiteElementsTest(FunctionalTest):

    def test_find_name(self):
        selenium_host = self.get_host_from_selenium(self.host)
        self.assertIn("Izzan Fakhril Islam", selenium_host.page_source)

    def test_title_text(self):
        selenium_host = self.get_host_from_selenium(self.host)
        self.assertIn("Todo List", selenium_host.page_source)

    def test_todo_list_table_exists(self):
        selenium_host = self.get_host_from_selenium(self.host)
        self.assertIn("Todo List Table", selenium_host.page_source)

    def test_add_todo_form_exists(self):
        selenium_host = self.get_host_from_selenium(self.host)
        self.assertIn("Add Todo", selenium_host.page_source)

    def test_add_todo_comment_form_exists(self):
        selenium_host = self.get_host_from_selenium(self.host)
        self.assertIn("Add Daily Todo List Comment", selenium_host.page_source)

