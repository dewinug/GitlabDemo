# Tutorial 5: Test Organization, separating test case files
import time

from django.contrib.staticfiles.testing import StaticLiveServerTestCase
from unittest import skip
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import WebDriverException


@skip("skipping functional test to get Gitlab CI pipeline work")
class FunctionalTest(StaticLiveServerTestCase):

    def setUp(self):
        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-dev-shm-usage')
        # chrome_options.add_argument('--disable-gpu')

        self.selenium = webdriver.Chrome('./chromedriver', chrome_options=chrome_options)

        self.cases = [
            (5, "oh, tidak"),
            (2, "sibuk tapi santai"),
            (0, "waktunya berlibur"),
        ]
        self.MAX_WAIT = 10
        self.host = self.live_server_url + "/tutorial-2/"
        self.selenium.implicitly_wait(3)

        super(FunctionalTest, self).setUp()

    def tearDown(self):
        self.selenium.quit()
        super(FunctionalTest, self).tearDown()

    def wait_for_row_list_in_table(self, row_text, table_id):
        start_time = time.time()
        selenium = self.selenium
        while True:
            try:
                table = selenium.find_element_by_id(table_id)
                rows = table.find_elements_by_tag_name("td")
                self.assertIn(row_text, [row.text for row in rows])
                return
            except (AssertionError, WebDriverException) as e:
                if time.time() - start_time > self.MAX_WAIT:
                    raise e
                time.sleep(0.5)

    # Same as wait_for_row_list_in_table but using lambda expressions
    def wait_for(self, fn):
        start_time = time.time()
        while True:
            try:
                return fn()
            except (AssertionError, WebDriverException) as e:
                if time.time() - start_time > self.MAX_WAIT:
                    raise e
                time.sleep(0.5)

    def get_host_from_selenium(self, url):
        selenium = self.selenium
        selenium.get(url)
        return selenium
