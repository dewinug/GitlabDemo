from .base import FunctionalTest
from selenium.webdriver.common.keys import Keys


class TodoCommentaryItemTest(FunctionalTest):

    def test_input_todo_commentary_item(self):
        selenium_host = self.get_host_from_selenium(self.host)

        todo_date = selenium_host.find_element_by_id('comment_date')
        todo_date.send_keys('23122019')

        todo_comment = selenium_host.find_element_by_id('comment')
        todo_comment.send_keys("Dummy comment")
        todo_comment.send_keys(Keys.ENTER)

        self.wait_for_row_list_in_table("Dummy comment", "todo_comment_table")
        self.wait_for(lambda: self.assertIn("Dummy comment", selenium_host.page_source))

    def test_input_todo_on_the_same_date_and_generate_comment(self):
        selenium_host = self.get_host_from_selenium(self.host)

        date = 24
        month_and_year = '112019'

        for n, comment in self.cases:
            time_str = 1045
            for i in range(n):
                todo_date = selenium_host.find_element_by_id('todo_date')
                todo_date.send_keys(str(date) + month_and_year)
                todo_date.send_keys(Keys.TAB)
                todo_date.send_keys(str(time_str))

                todo_text = selenium_host.find_element_by_id('activity')
                todo_text.send_keys('Dummy Activity ' + str(n))
                todo_text.send_keys(Keys.ENTER)

                time_str += 1

            todo_date = selenium_host.find_element_by_id('comment_date')
            todo_date.send_keys(str(date) + month_and_year)

            todo_comment = selenium_host.find_element_by_id('comment')
            todo_comment.send_keys(comment)
            todo_comment.send_keys(Keys.ENTER)

            if n != 0:
                self.wait_for_row_list_in_table("Dummy Activity " + str(n), "todo_table")
                self.wait_for(lambda: self.assertIn("Dummy Activity " + str(n), selenium_host.page_source))

            self.wait_for_row_list_in_table(comment, "todo_comment_table")
            self.wait_for(lambda: self.assertIn(comment, selenium_host.page_source))

            date += 1
