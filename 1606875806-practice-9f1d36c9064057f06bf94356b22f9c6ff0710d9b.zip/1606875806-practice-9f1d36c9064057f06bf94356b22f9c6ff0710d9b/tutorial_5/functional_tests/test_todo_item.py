import time

from .base import FunctionalTest
from selenium.webdriver.common.keys import Keys


class TodoItemTest(FunctionalTest):

    def test_input_todo_item(self):
        selenium_host = self.get_host_from_selenium(self.host)

        todo_date = selenium_host.find_element_by_id('todo_date')
        todo_date.send_keys('23052019')
        todo_date.send_keys(Keys.TAB)
        todo_date.send_keys('1245')

        todo_text = selenium_host.find_element_by_id('activity')
        todo_text.send_keys('Dummy')
        todo_text.send_keys(Keys.ENTER)

        self.wait_for_row_list_in_table("Dummy", "todo_table")
        self.wait_for(lambda: self.assertIn("Dummy", selenium_host.page_source))


