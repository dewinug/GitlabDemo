from django.apps import AppConfig


class Tutorial6Config(AppConfig):
    name = 'tutorial_6'
