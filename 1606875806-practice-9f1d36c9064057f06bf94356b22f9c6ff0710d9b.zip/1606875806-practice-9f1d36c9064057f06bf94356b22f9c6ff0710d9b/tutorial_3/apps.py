from django.apps import AppConfig


class Tutorial3Config(AppConfig):
    name = 'tutorial_3'
