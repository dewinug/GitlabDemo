# Tutorial 2 PMPL Unit Test, using Django's LiveServerTestCase

from django.test import LiveServerTestCase
from django.test import Client
from tutorial_2.views import index
from django.http import HttpRequest
from tutorial_2.models import TodoListCommentary, TodoList

DUMMY_TODO_ITEM = "Dummy todo item"
DUMMY_TODO_COMMENTARY_ITEM = "Dummy todo commentary item"


class Tutorial2UnitTest(LiveServerTestCase):

    def test_page_rendered_successful(self):
        print(self.live_server_url + "/tutorial-2/")
        response = Client().get(self.live_server_url + "/tutorial-2/")
        self.assertEqual(response.status_code, 200)

    def test_name_in_page(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('Izzan Fakhril Islam', html_response)

    def test_POST_request_create_todo(self):
        self.client.post(
            self.live_server_url + "/tutorial-2/add_todo/",
            data={
                'date': '2019-09-19T15:15',
                'activity': DUMMY_TODO_ITEM,
            }
        )
        todo_count = TodoList.objects.all().count()
        page_response = self.client.get(self.live_server_url + '/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertEqual(todo_count, 1)
        self.assertIn(DUMMY_TODO_ITEM, html_response)

    def test_POST_request_create_todo_commentary(self):
        self.client.post(
            self.live_server_url + "/tutorial-2/add_todo_commentary/",
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        todo_comment_count = TodoListCommentary.objects.all().count()
        page_response = self.client.get(self.live_server_url + '/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertEqual(todo_comment_count, 1)
        self.assertIn(DUMMY_TODO_COMMENTARY_ITEM, html_response)
