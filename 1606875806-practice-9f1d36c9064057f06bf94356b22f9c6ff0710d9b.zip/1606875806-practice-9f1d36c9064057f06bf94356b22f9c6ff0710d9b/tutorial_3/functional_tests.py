# Tutorial 2 PMPL Functional Test, using Django's LiveServerTestCase

import time
import unittest

from django.test import LiveServerTestCase
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import WebDriverException


@unittest.skip("excluded")
class Tutorial2FunctionalTest(LiveServerTestCase):

    def setUp(self):
        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        self.selenium = webdriver.Chrome('./chromedriver', chrome_options=chrome_options)

        self.cases = [
            (5, "oh, tidak"),
            (2, "sibuk tapi santai"),
            (0, "waktunya berlibur"),
        ]
        self.MAX_WAIT = 10
        self.host = self.live_server_url + "/tutorial-2/"
        super(Tutorial2FunctionalTest, self).setUp()

    def tearDown(self):
        self.selenium.quit()
        super(Tutorial2FunctionalTest, self).tearDown()

    def test_find_name(self):
        selenium = self.selenium
        selenium.get(self.host)
        self.assertIn('Izzan Fakhril Islam', selenium.page_source)

    def test_input_todo_item(self):
        start_time = time.time()
        selenium = self.selenium
        selenium.get(self.host)

        todo_date = selenium.find_element_by_id('todo_date')
        todo_date.send_keys('23052019')
        todo_date.send_keys(Keys.TAB)
        todo_date.send_keys('1245')

        todo_text = selenium.find_element_by_id('activity')
        todo_text.send_keys('Dummy')

        selenium.find_element_by_id('todo_submit').click()
        while True:
            try:
                table = selenium.find_element_by_id("todo_table")
                rows = table.find_elements_by_tag_name("td")
                self.assertIn('Dummy', [row.text for row in rows])
                return
            except (AssertionError, WebDriverException) as e:
                if time.time() - start_time > self.MAX_WAIT:
                    raise e
                time.sleep(0.5)

    def test_input_todo_commentary_item(self):
        start_time = time.time()
        selenium = self.selenium
        selenium.get(self.host)

        todo_date = selenium.find_element_by_id('comment_date')
        todo_date.send_keys('23122019')

        todo_comment = selenium.find_element_by_id('comment')
        todo_comment.send_keys('Dummy comment')

        selenium.find_element_by_id('comment_submit').click()
        while True:
            try:
                table = selenium.find_element_by_id("todo_comment_table")
                rows = table.find_elements_by_tag_name("td")
                self.assertIn("Dummy comment", [row.text for row in rows])
                return
            except (AssertionError, WebDriverException) as e:
                if time.time() - start_time > self.MAX_WAIT:
                    raise e
                time.sleep(0.5)

    def test_input_todo_on_the_same_date_and_generate_comment(self):
        start_time = time.time()
        selenium = self.selenium
        selenium.get(self.host)
        date = 24
        month_and_year = '112019'

        for n, comment in self.cases:
            time_str = 1045
            for i in range(n):
                todo_date = selenium.find_element_by_id('todo_date')
                todo_date.send_keys(str(date) + month_and_year)
                todo_date.send_keys(Keys.TAB)
                todo_date.send_keys(str(time_str))

                todo_text = selenium.find_element_by_id('activity')
                todo_text.send_keys('Dummy Activity ' + str(n))

                selenium.find_element_by_id('todo_submit').click()
                time_str += 1

            todo_date = selenium.find_element_by_id('comment_date')
            todo_date.send_keys(str(date) + month_and_year)

            todo_comment = selenium.find_element_by_id('comment')
            todo_comment.send_keys(comment)
            selenium.find_element_by_id('comment_submit').click()
            while True:
                try:
                    table_comment = selenium.find_element_by_id("todo_comment_table")
                    rows_comment = table_comment.find_elements_by_tag_name("td")

                    table_todo = selenium.find_element_by_id("todo_table")
                    rows_todo = table_todo.find_elements_by_tag_name("td")

                    self.assertIn('Dummy Activity ' + str(n), [row.text for row in rows_todo])
                    self.assertIn(comment, [row.text for row in rows_comment])
                    date += 1
                    return
                except (AssertionError, WebDriverException) as e:
                    if time.time() - start_time > self.MAX_WAIT:
                        raise e
                    time.sleep(0.5)
