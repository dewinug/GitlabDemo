from django.test import TestCase
from django.test import Client
# from ..views_mutation import generate_comment_by_todo_count_in_a_same_day
from django.http import HttpRequest
from django.utils import timezone

DUMMY_TODO_ITEM = "Dummy todo item"
TODO_COUNT = 4


class Tutorial2MutationUnitTest(TestCase):

    def test_generate_comment_on_adding_todo_at_the_same_date(self):
        base_number = 15
        self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-12T15:' + str(base_number),
                'activity': DUMMY_TODO_ITEM
            }
        )
        base_number += 1
        page_response = self.client.get('/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertIn('sibuk tapi santai', html_response)

        for i in range(TODO_COUNT):
            self.client.post(
                '/tutorial-2/add_todo/',
                data={
                    'date': '2019-09-12T15:' + str(base_number),
                    'activity': DUMMY_TODO_ITEM
                }
            )
            base_number += 1
        page_response = self.client.get('/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertIn('oh tidak', html_response)

