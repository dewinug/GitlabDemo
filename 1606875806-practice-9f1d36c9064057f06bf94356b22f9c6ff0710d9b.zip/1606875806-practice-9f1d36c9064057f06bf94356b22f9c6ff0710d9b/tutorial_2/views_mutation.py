from django.core.exceptions import ValidationError
from .models import TodoListCommentary, TodoList
from datetime import datetime


# def generate_comment_by_todo_count_in_a_same_day(request):
#     if request.method == 'POST':
#         try:
#             date_time_request = datetime.strptime(request.POST['date'], '%Y-%m-%dT%H:%M')
#             date_request = date_time_request.date()
#             todo_count_by_date = TodoList.objects.filter(date__date=date_request).count()
#             if todo_count_by_date == 0:
#                 comment = "yey, waktunya berlibur!"
#             elif todo_count_by_date < 5:
#                 comment = "sibuk tapi santai"
#             else:
#                 comment = "oh tidak"
#
#             TodoListCommentary.objects.create(
#                 comment=comment,
#                 date=date_request
#             )
#         except (ValidationError, ValueError) as e:
#             print(type(e))


def get_comment(count):
    if count == 0:
        comment = "yey, waktunya berlibur"
    elif count < 5:
        comment = "sibuk tapi santai"
    else:
        comment = "oh tidak"
    return comment
