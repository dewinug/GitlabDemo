from django.apps import AppConfig


class Tutorial2Config(AppConfig):
    name = 'tutorial_2'
