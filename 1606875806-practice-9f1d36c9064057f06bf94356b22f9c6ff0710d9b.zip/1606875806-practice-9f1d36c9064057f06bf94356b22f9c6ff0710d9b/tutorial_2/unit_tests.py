from django.test import TestCase
from django.test import Client
from .views import index
from .models import TodoListCommentary, TodoList
from django.http import HttpRequest
from django.utils import timezone

# Create your tests here.
DUMMY_TODO_ITEM = "Dummy todo item"
DUMMY_TODO_COMMENTARY_ITEM = "Dummy todo commentary item"


class Tutorial2UnitTest(TestCase):

    def test_page_rendered_successfully(self):
        response = Client().get('/tutorial-2/')
        self.assertEqual(response.status_code, 200)

    def test_name_in_page(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('Izzan Fakhril Islam', html_response)

    def test_todo_table_rendered_successfully(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('<th><h5><b>Todo</b></h5></th>', html_response)

    def test_todo_commentary_table_rendered_successfully(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('<th><h5><b>Comment</b></h5></th>', html_response)

    def test_add_todo_item_via_model(self):
        TodoList.objects.create(
            date=timezone.now(),
            todo_list=DUMMY_TODO_ITEM
        )
        todo_count = TodoList.objects.all().count()
        self.assertEqual(todo_count, 1)

    def test_add_todo_commentary_item_via_model(self):
        TodoListCommentary.objects.create(
            date=timezone.now(),
            comment=DUMMY_TODO_COMMENTARY_ITEM
        )
        todo_commentary_count = TodoListCommentary.objects.all().count()
        self.assertEqual(todo_commentary_count, 1)

    def test_POST_request_create_todo(self):
        self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-12T15:15',
                'activity': DUMMY_TODO_ITEM
            }
        )
        todo_count = TodoList.objects.all().count()
        page_response = self.client.get('/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertEqual(todo_count, 1)
        self.assertIn(DUMMY_TODO_ITEM, html_response)

    def test_POST_request_create_todo_commentary(self):
        self.client.post(
            '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        todo_comment_count = TodoListCommentary.objects.all().count()
        page_response = self.client.get('/tutorial-2/')
        html_response = page_response.content.decode('utf8')

        self.assertEqual(todo_comment_count, 1)
        self.assertIn(DUMMY_TODO_COMMENTARY_ITEM, html_response)
