from django.conf.urls import url
from .views import index, add_todo, add_todo_commentary

urlpatterns = [
    url(r'^$', index, name='index'),
    url(r'add_todo/$', add_todo, name='add_todo'),
    url(r'add_todo_commentary/$', add_todo_commentary, name='add_todo_commentary')
]
