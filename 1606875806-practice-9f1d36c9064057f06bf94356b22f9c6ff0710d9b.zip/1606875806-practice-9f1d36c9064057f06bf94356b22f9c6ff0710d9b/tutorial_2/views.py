from django.core.exceptions import ValidationError
from django.shortcuts import render
from .models import TodoList, TodoListCommentary
from datetime import datetime
from django.http import HttpResponseRedirect
from django.urls import reverse
from .views_mutation import get_comment

# Create your views here.
todo = {}
todo_commentary = {}
HTML_FILE = "tutorial_2.html"
URL = "/tutorial-2/"
response = {
    'author': 'Izzan Fakhril Islam',
    'npm': '1606875806',
}


def index(request):
    todo_dict = TodoList.objects.all().values()
    todo_commentary_dict = TodoListCommentary.objects.all().values()
    response['todos_dict'] = convert_queryset_into_json(todo_dict)
    response['todos_commentary_dict'] = convert_queryset_into_json(todo_commentary_dict)

    return render(request, HTML_FILE, response)


def add_todo(request):
    if request.method == 'POST':
        try:
            date = datetime.strptime(request.POST['date'], '%Y-%m-%dT%H:%M')
            TodoList.objects.create(
                todo_list=request.POST['activity'],
                date=date
            )
            date_request = date.date()
            todo_count_by_date = TodoList.objects.filter(date__date=date_request).count()
            TodoListCommentary.objects.create(
                 comment=get_comment(todo_count_by_date),
                 date=date_request
            )
            return HttpResponseRedirect(reverse('tutorial-2:index'))
        except (ValueError, ValidationError) as e:
            todo = TodoList.objects.all().values()
            response['error_msg'] = 'ERROR: Failed to add Todo List'
            response['todos_dict'] = todo

            return render(request, HTML_FILE, response)


def add_todo_commentary(request):
    if request.method == 'POST':
        try:
            date = datetime.strptime(request.POST['date'], '%Y-%m-%d')
            TodoListCommentary.objects.create(
                comment=request.POST['comment'],
                date=date
            )
            return HttpResponseRedirect(reverse('tutorial-2:index'))
        except (ValueError, ValidationError) as e:
            print(type(e))
            todo_commentary = TodoListCommentary.objects.all().values()
            response['commentary_error_msg'] = 'ERROR: Failed to add Todo List Commentary'
            response['todos_commentary_dict'] = todo_commentary

            return render(request, HTML_FILE, response)


def convert_queryset_into_json(queryset_dict):
    res = []
    for data in queryset_dict:
        res.append(data)
    return res
