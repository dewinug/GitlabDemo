from django.db import models


# Create your models here.
class TodoList(models.Model):
    date = models.DateTimeField(blank=False)
    todo_list = models.TextField(max_length=100, blank=False)

    def __str__(self):
        return "Todo at %s: %s" % (self.date.timestamp(), self.todo_list)


class TodoListCommentary(models.Model):
    date = models.DateField(blank=False)
    comment = models.TextField(max_length=100, blank=False)

    def __str__(self):
        return "Commentary at %s: %s" % (self.date.__str__, self.comment)
