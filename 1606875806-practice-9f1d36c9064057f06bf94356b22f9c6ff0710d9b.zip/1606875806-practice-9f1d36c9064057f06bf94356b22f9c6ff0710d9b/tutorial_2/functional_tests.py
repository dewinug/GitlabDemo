import os
from django.test import TestCase

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys

GITLAB_ENV = os.environ.get("HEROKU_APP_HOST") != None


class Tutorial2FunctionalTest(TestCase):

    def setUp(self):
        chrome_options = Options()
        chrome_options.add_argument('--dns-prefetch-disable')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-gpu')
        self.selenium = webdriver.Chrome('./chromedriver', chrome_options=chrome_options)

        self.localhost = "http://127.0.0.1:8000/tutorial-2/"

        self.cases = [
            (5, "oh, tidak"),
            (2, "sibuk tapi santai"),
            (0, "yey, waktunya berlibur"),
        ]
        print("GITLAB ENV:", GITLAB_ENV)
        if GITLAB_ENV:
            self.localhost = "https://pmpl-izzan.herokuapp.com/tutorial-2/"

        super(Tutorial2FunctionalTest, self).setUp()

    def tearDown(self):
        self.selenium.quit()
        super(Tutorial2FunctionalTest, self).tearDown()

    def test_find_name(self):
        selenium = self.selenium
        selenium.get(self.localhost)
        self.assertIn('Izzan Fakhril Islam', selenium.page_source)

    def test_input_todo_item(self):
        selenium = self.selenium
        selenium.get(self.localhost)

        todo_date = selenium.find_element_by_id('todo_date')
        todo_date.send_keys('23052019')
        todo_date.send_keys(Keys.TAB)
        todo_date.send_keys('1245')

        todo_text = selenium.find_element_by_id('activity')
        todo_text.send_keys('Dummy')

        selenium.find_element_by_id('todo_submit').click()
        self.assertIn('Dummy', selenium.page_source)

    def test_input_todo_commentary_item(self):
        print("LOCALHOST:", self.localhost)
        selenium = self.selenium
        selenium.get(self.localhost)

        todo_date = selenium.find_element_by_id('comment_date')
        todo_date.send_keys('23122019')

        todo_comment = selenium.find_element_by_id('comment')
        todo_comment.send_keys('Dummy comment')

        selenium.find_element_by_id('comment_submit').click()
        self.assertIn('Dummy comment', selenium.page_source)

    def test_input_todo_on_the_same_date_and_generate_comment(self):
        selenium = self.selenium
        selenium.get(self.localhost)
        date = 24
        month_and_year = '112019'

        for n, comment in self.cases:
            time = 1045
            for i in range(n):
                todo_date = selenium.find_element_by_id('todo_date')
                todo_date.send_keys(str(date) + month_and_year)
                todo_date.send_keys(Keys.TAB)
                todo_date.send_keys(str(time))

                todo_text = selenium.find_element_by_id('activity')
                todo_text.send_keys('Dummy Activity' + str(n))

                selenium.find_element_by_id('todo_submit').click()
                time += 1

            todo_date = selenium.find_element_by_id('comment_date')
            todo_date.send_keys(str(date) + month_and_year)

            todo_comment = selenium.find_element_by_id('comment')
            todo_comment.send_keys(comment)
            selenium.find_element_by_id('comment_submit').click()

            self.assertIn(comment, selenium.page_source)
            date += 1
