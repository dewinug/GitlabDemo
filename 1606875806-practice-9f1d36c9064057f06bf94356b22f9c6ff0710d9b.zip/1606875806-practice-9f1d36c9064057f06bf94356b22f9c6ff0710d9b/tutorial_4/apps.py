from django.apps import AppConfig


class Tutorial4Config(AppConfig):
    name = "tutorial_4"
