from django.test import LiveServerTestCase, TestCase
from django.test import Client
from tutorial_2.views import index
from django.http import HttpRequest
from tutorial_2.models import TodoListCommentary, TodoList

DUMMY_TODO_ITEM = "Dummy todo item"
DUMMY_TODO_COMMENTARY_ITEM = "Dummy todo commentary item"


class Tutorial2UnitTest(TestCase):

    def test_use_correct_template(self):
        response = self.client.get('/tutorial-2/')
        self.assertTemplateUsed(response, 'tutorial_2.html')

    def test_can_save_POST_request_todo(self):
        self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-05T14:31',
                'activity': DUMMY_TODO_ITEM
            }
        )
        todo_count = TodoList.objects.count()
        new_todo = TodoList.objects.first()

        self.assertEqual(todo_count, 1)
        self.assertEqual(getattr(new_todo, 'todo_list'), DUMMY_TODO_ITEM)

    def test_can_save_POST_request_todo_commentary(self):
        self.client.post(
            '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        todo_commentary_count = TodoListCommentary.objects.count()
        new_todo_commentary = TodoListCommentary.objects.first()

        self.assertEqual(todo_commentary_count, 1)
        self.assertEqual(getattr(new_todo_commentary, 'comment'), DUMMY_TODO_COMMENTARY_ITEM)

    def test_redirects_after_POST_todo(self):
        response = self.client.post(
            '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-05T14:31',
                'activity': DUMMY_TODO_ITEM
            }
        )
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, '/tutorial-2/')

    def test_redirects_after_POST_todo_commentary(self):
        response = self.client.post(
            '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, '/tutorial-2/')


class Tutorial2LiveServerUnitTest(LiveServerTestCase):
    def test_use_correct_template(self):
        response = self.client.get(self.live_server_url + '/tutorial-2/')
        self.assertTemplateUsed(response, 'tutorial_2.html')

    def test_can_save_POST_request_todo(self):
        self.client.post(
            self.live_server_url + '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-05T14:31',
                'activity': DUMMY_TODO_ITEM
            }
        )
        todo_count = TodoList.objects.count()
        new_todo = TodoList.objects.first()

        self.assertEqual(todo_count, 1)
        self.assertEqual(getattr(new_todo, 'todo_list'), DUMMY_TODO_ITEM)

    def test_can_save_POST_request_todo_commentary(self):
        self.client.post(
            self.live_server_url + '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        todo_commentary_count = TodoListCommentary.objects.count()
        new_todo_commentary = TodoListCommentary.objects.first()

        self.assertEqual(todo_commentary_count, 1)
        self.assertEqual(getattr(new_todo_commentary, 'comment'), DUMMY_TODO_COMMENTARY_ITEM)

    def test_redirects_after_POST_todo(self):
        response = self.client.post(
            self.live_server_url + '/tutorial-2/add_todo/',
            data={
                'date': '2019-09-05T14:31',
                'activity': DUMMY_TODO_ITEM
            }
        )
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, '/tutorial-2/')

    def test_redirects_after_POST_todo_commentary(self):
        response = self.client.post(
            self.live_server_url + '/tutorial-2/add_todo_commentary/',
            data={
                'date': '2019-09-12',
                'comment': DUMMY_TODO_COMMENTARY_ITEM
            }
        )
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, '/tutorial-2/')

