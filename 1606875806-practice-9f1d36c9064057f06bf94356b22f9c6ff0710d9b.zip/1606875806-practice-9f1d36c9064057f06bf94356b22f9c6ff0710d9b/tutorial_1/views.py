from django.shortcuts import render
from datetime import datetime, date

# Create your views here.
NAME = "Izzan Fakhril Islam"
CURRENT_YEAR = int(datetime.now().strftime("%Y"))
BIRTH_DATE = date(1998, 7, 1)


def index(request):
    html = 'index_tutorial1.html'
    response = {
        'name': NAME,
        'age': calculate_age(BIRTH_DATE.year),
    }
    return render(request, html, response)


def calculate_age(birth_year):
    return CURRENT_YEAR - birth_year if birth_year <= CURRENT_YEAR else 0
