from django.test import TestCase
from .views import NAME
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


class Tutorial1FunctionalTest(TestCase):

    def setUp(self):
        chrome_options = Options()
        chrome_options.add_argument('--dns-prefetch-disable')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-gpu')
        self.selenium = webdriver.Chrome('./chromedriver', chrome_options=chrome_options)
        super(Tutorial1FunctionalTest, self).setUp()

    def tearDown(self):
        self.selenium.quit()
        super(Tutorial1FunctionalTest, self).tearDown()

    def test_find_name(self):
        selenium = self.selenium
        selenium.get('http://127.0.0.1:8000/tutorial-1/')
        self.assertIn(NAME, selenium.page_source)

    def test_find_age(self):
        selenium = self.selenium
        selenium.get('http://127.0.0.1:8000/tutorial-1/')
        self.assertIn('21', selenium.page_source)
