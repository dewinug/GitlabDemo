from django.test import TestCase
from django.test import Client
from .views import index, NAME, calculate_age
from django.http import HttpRequest
from datetime import date


# Create your tests here.

class Tutorial1UnitTest(TestCase):

    def test_hello_name_is_exist(self):
        response = Client().get('/tutorial-1/')
        self.assertEqual(response.status_code, 200)

    def test_name_in_page(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertIn('<title>' + NAME + '</title>', html_response)

    def test_index_contains_age(self):
        request = HttpRequest()
        response = index(request)
        html_response = response.content.decode('utf8')
        self.assertRegex(html_response, r'<article>I am [0-9]\d+ years old</article>')

    def test_calculate_age_function(self):
        self.assertEqual(0, calculate_age(date.today().year))
        self.assertEqual(19, calculate_age(2000))
        self.assertEqual(29, calculate_age(1990))
