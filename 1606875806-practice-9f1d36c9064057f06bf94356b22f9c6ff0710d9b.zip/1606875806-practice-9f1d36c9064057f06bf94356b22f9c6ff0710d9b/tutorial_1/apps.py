from django.apps import AppConfig


class Tutorial1Config(AppConfig):
    name = 'tutorial_1'
